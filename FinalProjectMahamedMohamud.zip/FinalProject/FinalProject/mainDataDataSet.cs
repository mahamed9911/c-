﻿namespace FinalProject
{


    partial class mainDataDataSet
    {
    }
}

namespace FinalProject.mainDataDataSetTableAdapters {
    
    
    public partial class UsersTableAdapter {
    }
}
